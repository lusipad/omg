# Open Duck Mini v2

Model source: Antoine Pirrone (apirrone) and Open Duck Mini contributors, commit b23317a485b3cec7d8417f352478778b3475173c.
https://github.com/apirrone/Open_Duck_Mini/tree/b23317a485b3cec7d8417f352478778b3475173c/mini_bdx/robots/open_duck_mini_v2

Use scene_position.xml for the original fixed-base, position-controlled scene. The alternative scene.xml loads the original floating-base model with torque-style motor inputs. Both scenes use the same 45 source meshes. All MJCF and STL files, LICENSE and thanks.md are reproduced byte for byte from that revision. The upstream repository supplies the Apache License 2.0 in LICENSE. See thanks.md for the upstream project acknowledgments.
