# Robotiq 2F-85

Copyright (c) 2013, ROS-Industrial. All rights reserved.

Model: Google DeepMind MuJoCo Menagerie, fixed commit 71f066ad0be9cd271f7ed58c030243ef157af9f4.
https://github.com/google-deepmind/mujoco_menagerie/tree/71f066ad0be9cd271f7ed58c030243ef157af9f4/robotiq_2f85

The original robot description is derived from the ROS-Industrial URDF: https://github.com/ros-industrial/robotiq/tree/kinetic-devel/robotiq_2f_85_gripper_visualization
The two MJCF files, mesh assets, and directory-specific BSD-2-Clause LICENSE are byte-identical to that revision.
Suggested entry for this package: scene.xml. For the gripper alone, use 2f85.xml.
