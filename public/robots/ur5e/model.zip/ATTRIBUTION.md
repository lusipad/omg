# Universal Robots UR5e

Copyright 2018 ROS Industrial Consortium

Model: Google DeepMind MuJoCo Menagerie, fixed commit 71f066ad0be9cd271f7ed58c030243ef157af9f4.
https://github.com/google-deepmind/mujoco_menagerie/tree/71f066ad0be9cd271f7ed58c030243ef157af9f4/universal_robots_ur5e

The original robot description is derived from the ROS-Industrial URDF: https://github.com/ros-industrial/universal_robot/tree/kinetic-devel/ur_e_description
The two MJCF files, mesh assets, and directory-specific BSD-3-Clause LICENSE are byte-identical to that revision.
Suggested entry for this package: scene.xml.
